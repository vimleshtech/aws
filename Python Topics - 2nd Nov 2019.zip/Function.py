import os
os.chdir(r'C:\Users\vkumar15\Desktop\Learning & Training')

def create_file():

    #create file if not exist 
    w = open('new_file.txt','a')

    w.write('hi this is my test file ')
    w.close()


def read_data():
    o = open('fruits_data.txt')
    print(o.read())


def wel():
    print('test code ')
    
wel() #call to wel 
read_data()
