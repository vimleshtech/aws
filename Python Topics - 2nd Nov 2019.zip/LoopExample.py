#loop : is iterator or repeation of statement
#there are following types i. while ii. for loop

#while loop
i =1 #init 
while i<10: #condition 
    print(i)
    i=i+1 #incrementer 


#for
for x in range(1,10,1): #from 1 to <10 
    print(x)
    

#input and output
for i in range(1,10):
    d = input('enter data :')
    print('you have entered ',d)
    
