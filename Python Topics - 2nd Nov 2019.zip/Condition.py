server_type = input('enter server type :')

#condition : is decision making statement 
if server_type == 'webserver' or server_type =='web':
    print('install IIS if windows server, other tomcat for linux ')

elif server_type=='db':
    print('install mysql for free or mssql server for paid ')

else:
    print('conidition is not match')
    
    
    
    
