d = ['fklfhfgf' , 'kfjhhfg fh gf']


print(d)

for x in d:
    print(x)
    
