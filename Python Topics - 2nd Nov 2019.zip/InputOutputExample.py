#input() is function to read data from user

storage = input('enter storage :') #default input type is str
name = input('enter name :')  #default input type is str


print(storage)
print(name)

print(type(storage))
print(type(name))


