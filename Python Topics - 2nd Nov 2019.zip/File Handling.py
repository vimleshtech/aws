'''
File Handling : read and write data from and with file

There are following inbuilt function
open(path,mode)
 path: physical location of file
 mode:
     r -read
     w -write
     a -append
read()  : read all data from file 
readline(): read first line , read line by line 
readlines() : read all lines from file and convert to list, every line will become on item of list 
close() : save and close the instance of file      
'''

#import library 
import os

#changer directory 
os.chdir(r'C:\Users\vkumar15\Desktop\Learning & Training')

#get list of files and folder from current directory 
f= os.listdir() 


#print(f)
#iterate the all files and and folder, read one by one

#get count of all .txt files
c = 0
for a in f:
    #print(a)
    if a.endswith('.txt'):
        c=c+1
print('no of txt file is ',c)


#read from file
o = open('fruits_data.txt')
#print(o.read())
#print(o.readline())

d = o.readlines()
print(d)
#row count
print(len(d))

for r in d:
    print(r)
    

o.close()


#create file if not exist 
w = open('new_file.txt','a')

w.write('hi this is my test file ')
w.close()
print('file is saved ')






















    

                
    






