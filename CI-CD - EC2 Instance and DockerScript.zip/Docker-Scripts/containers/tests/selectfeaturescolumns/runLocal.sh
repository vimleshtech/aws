#!/bin/sh
#
# &copy; 2017-2018 Regents of the University of California and the Broad Institute. All rights reserved.
#
LOCAL_DIR=
. runConfig.sh

. ../../DinD_testing_scripts/runLocalInner.sh

