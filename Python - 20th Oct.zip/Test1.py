a =1
b =344

c =a+b


print(c)


c = a-b
print(c)
